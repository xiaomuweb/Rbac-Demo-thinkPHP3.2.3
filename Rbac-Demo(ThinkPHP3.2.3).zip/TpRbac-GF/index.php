<?php
/**
 * 入口文件
 * Time: 17:06
 */
header("ContetnType:text/html;Charset=utf8");

//开启调试模式
define('APP_DEBUG',true);

//给静态资源访问目录设置常量，方便后期维护
//给Admin组设置常量
define('SET_DIR','/TpProject/TpRbac-GF/');
define('ADMIN_PUBLIC_DIR', '/TpProject/TpRbac-GF/Public/Admin/');
define('ADMIN_PUBLIC_DIR_ASSETS','/TpProject/TpRbac-GF/Public/Admin/assets/');
define('ADMIN_PUBLIC_DIR_FLAT', '/TpProject/TpRbac-GF/Public/Admin/Flat/');

//引入入口文件
require '../ThinkPHP/ThinkPHP.php';