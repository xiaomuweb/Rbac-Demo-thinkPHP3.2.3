<?php if (!defined('THINK_PATH')) exit();?><html>
<h1 style="display: block;width: 100%;margin: 100px auto;margin-top:15%;text-align: center;color: #21BA45;">
    RBAC权限管理——完整演示DEMO(基于ThinkPHP3.2.3)
</h1>
</html>