<?php if (!defined('THINK_PATH')) exit();?><html>
<h1 style="display: block;width: 100%;margin: 100px auto;margin-top:15%;text-align: center;color: #21BA45;">
    分类管理首页......
</h1>
</html>