<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>编辑节点</title>
	<meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">
	<!-- Loading Bootstrap -->
	<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/vendor/bootstrap.min.css" rel="stylesheet">
	<!-- Loading Flat UI -->
	<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/flat-ui.css" rel="stylesheet">
	<!--<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>docs/assets/css/demo.css" rel="stylesheet">-->
	<link rel="shortcut icon" href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>img/favicon.ico">

</head>
<body>
	<div class="alert alert-success" style="text-align: center;">编辑节点</div>
	<form action="<?php echo U('Admin/Rbac/nodeHandel');?>" METHOD="post" ENCTYPE="multipart/form-data">
		<input type="hidden" name="id" value="<?php echo ($nodeData["id"]); ?>">
		<table class="table table-bordered">
			<tr class="active">
				<th style="text-align:right;width: 15%;padding-right: 20px;"><?php echo ($type); ?>名称</th>
				<th><input type="text" name="name" value="<?php echo ($nodeData["name"]); ?>" placeholder="必须为英文名称" class="form-control"></th>
			</tr>
			<tr class="active">
				<th style="text-align:right;width: 15%;padding-right: 20px;"><?php echo ($type); ?>描述</th>
				<th><input type="text" name="title" value="<?php echo ($nodeData["title"]); ?>" class="form-control"></th>
			</tr>
			<tr class="active">
				<th style="text-align:right;width: 15%;padding-right: 20px;">是否开启状态</th>
				<th>
					<input type="radio" name="status" value="0" <?php if($nodeData["status"] == 0): ?>checked="checked"<?php endif; ?> >否
					&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="radio" name="status" value="1" <?php if($nodeData["status"] == 1): ?>checked="checked"<?php endif; ?> >是
					<span style="font-weight: 200;color: red;">
						 &nbsp;&nbsp;&nbsp;&nbsp;（注意：只有开启状该节点的权限才能生效！）
					</span>
				</th>
			</tr>
			<tr class="active">
				<th style="text-align:right;width: 15%;padding-right: 20px;">排序</th>
				<input type="hidden" name="pid" value="<?php echo ($nodeData["pid"]); ?>">
				<input type="hidden" name="level" value="<?php echo ($nodeData["level"]); ?>">
				<th><input type="text" name="sort" value="<?php echo ($nodeData["sort"]); ?>" class="form-control"></th>
			</tr>
		</table>
		<button type="submit" class="btn btn-primary btn-lg btn-block">确 认 添 加</button>
	</form>
</body>
</html>