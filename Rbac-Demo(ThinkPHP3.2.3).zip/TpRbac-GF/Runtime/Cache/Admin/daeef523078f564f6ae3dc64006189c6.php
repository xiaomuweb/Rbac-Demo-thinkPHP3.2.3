<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>编辑用户</title>
	<meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">
	<!-- Loading Bootstrap -->
	<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/vendor/bootstrap.min.css" rel="stylesheet">
	<!-- Loading Flat UI -->
	<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/flat-ui.css" rel="stylesheet">
	<!--<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>docs/assets/css/demo.css" rel="stylesheet">-->
	<link rel="shortcut icon" href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>img/favicon.ico">

</head>
<body>
	<div class="alert alert-success" style="text-align: center;">编辑用户</div>
	<form action="<?php echo U('Admin/Rbac/userHandel');?>" METHOD="post" ENCTYPE="multipart/form-data">
		<input type="hidden" name="id" value="<?php echo ($userData["id"]); ?>">
		<table class="table table-bordered">
			<tr class="active">
				<th style="text-align:right;width: 15%;padding-right: 20px;">用户名称</th>
				<th><input type="text" name="name" value="<?php echo ($userData["name"]); ?>" class="form-control"></th>
			</tr>
			<tr class="active">
				<th style="text-align:right;width: 15%;padding-right: 20px;">用户密码</th>
				<th><input type="text" name="password" placeholder="请重新设定密码!" class="form-control"></th>
			</tr>
			<tr class="active">
				<th style="text-align:right;width: 15%;padding-right: 20px;">分配角色(组别)</th>
				<th>
					<?php if(is_array($roleData)): foreach($roleData as $key=>$vo): ?><span class="" style="display:inline-block; padding:4px 8px;border:1px solid #DDDDDD;margin-right: 20px;margin-bottom: 10px;border-radius: 5px;background: white;">
							<?php echo ($vo["name"]); ?>&nbsp;&nbsp;&nbsp;
							<input type="checkbox" name="role_id[]" value="<?php echo ($vo["id"]); ?>" <?php if(in_array(($vo["id"]), is_array($role_ids)?$role_ids:explode(',',$role_ids))): ?>checked="checked"<?php endif; ?> >
						</span><?php endforeach; endif; ?>
				</th>
			</tr>
		</table>
		<button type="submit" class="btn btn-primary btn-lg btn-block">确 认 添 加</button>
	</form>
</body>
</html>