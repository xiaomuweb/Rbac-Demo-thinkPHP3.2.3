<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>分配权限</title>
		<meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">
	    <!-- Loading Bootstrap -->
	    <link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/vendor/bootstrap.min.css" rel="stylesheet">
	    <!-- Loading Flat UI -->
	    <link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/flat-ui.css" rel="stylesheet">
	    <!--<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>docs/assets/css/demo.css" rel="stylesheet">-->
	    <link rel="shortcut icon" href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>img/favicon.ico">
		<script src="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>/js/jquery-1.8.2.min.js"></script>
		<!--权限选择效果-->
		<script>
			$(function () {
				$('input[level=1]').click(function () {
					var inputs = $(this).parents('.app').find('input');
					$(this).attr('checked') ? inputs.attr('checked','checked'):inputs.removeAttr('checked');
				});

				$('input[level=2]').click(function () {
					var inputs = $(this).parents('tr').next('tr').find('input');
					$(this).attr('checked') ? inputs.attr('checked','checked') : inputs.removeAttr('checked');
					//level2如果选中，那么相应的level1必须选中
					if(inputs.attr('checked')){
						$(this).parents('tr').siblings().first().find('input').attr('checked','checked');
					}
				});

				$('input[level=3]').click(function () {
					//level3如果选中，那么相应的level2必须选中
					if($(this).attr('checked')){
						var input = $(this).parents('.method').prev().find('input');
						input.attr('checked','checked');
						//level2如果选中，那么相应的level1必须选中
						$(this).parents('tr').siblings().first().find('input').attr('checked','checked');
					}
				});
			})
		</script>
	</head>
	<body>
		<div class="alert alert-success" style="text-align: center;">分配权限</div>
		<div class="alert" style="border-bottom: 1px solid #dddddd;">
			<a href="<?php echo U('Admin/Rbac/role');?>" class="btn btn-success" style="margin-right: 20px;"> 返   回 </a>
			您正在为<strong> <?php echo ($name); ?> </strong>分配权限
		</div>
		<form action="<?php echo U('Admin/Rbac/editAccess',array('rid'=>$rid));?>" method="post">
			<?php if(is_array($node)): foreach($node as $key=>$app): ?><table class="table app" style="margin-bottom: 50px;border: 1px solid #DDDDDD;">
					<tr>
						<th>
							<?php echo ($app["title"]); ?>&nbsp;&nbsp;
							<input type="checkbox" name="access[]" value="<?php echo ($app["id"]); ?>-1" level="1" <?php if(in_array(($app["id"]), is_array($nids)?$nids:explode(',',$nids))): ?>checked='checked'<?php endif; ?>>
						</th>
					</tr>
					<?php if(is_array($app["child"])): foreach($app["child"] as $key=>$action): ?><tr>
							<td class="active">
								<span style="padding-right: 1%;">
									<?php echo ($action["title"]); ?>&nbsp;&nbsp;
									<input type="checkbox" name="access[]" value="<?php echo ($action["id"]); ?>-2" level="2" <?php if(in_array(($action["id"]), is_array($nids)?$nids:explode(',',$nids))): ?>checked='checked'<?php endif; ?> >
								</span>
							</td>
						</tr>
						<tr class="method">
							<td>
								<?php if(is_array($action["child"])): foreach($action["child"] as $key=>$method): ?><span class="" style="display:inline-block; padding:4px 8px;border:1px solid #DDDDDD;margin-right: 20px;margin-bottom: 10px;border-radius: 5px;">
										<span>
											<?php echo ($method["title"]); ?>&nbsp;&nbsp;
											<input type="checkbox" name="access[]" value="<?php echo ($method["id"]); ?>-3" level="3" <?php if(in_array(($method["id"]), is_array($nids)?$nids:explode(',',$nids))): ?>checked='checked'<?php endif; ?> />
										</span>
									</span><?php endforeach; endif; ?>
							</td>
						</tr><?php endforeach; endif; ?>
				</table><?php endforeach; endif; ?>
			<button type="submit" class="btn btn-primary btn-lg btn-block">确 认 保 存</button>
		</form>
	</body>
</html>