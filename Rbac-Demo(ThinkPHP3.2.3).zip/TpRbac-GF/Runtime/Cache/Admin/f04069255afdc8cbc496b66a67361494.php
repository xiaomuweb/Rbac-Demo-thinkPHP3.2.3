<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>节点列表</title>
		<meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">
	    <!-- Loading Bootstrap -->
	    <link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/vendor/bootstrap.min.css" rel="stylesheet">
	    <!-- Loading Flat UI -->
	    <link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/flat-ui.css" rel="stylesheet">
	    <!--<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>docs/assets/css/demo.css" rel="stylesheet">-->
	    <link rel="shortcut icon" href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>img/favicon.ico">
	</head>
	<body>
		<div class="alert alert-success" style="text-align: center;">节点列表</div>
		<a href="<?php echo U('Admin/Rbac/addNode');?>" class="btn btn-success btn-lg" style="float:left;margin-bottom: 2%;">添加应用</a>
		<?php if(is_array($nodeData)): foreach($nodeData as $key=>$app): ?><table class="table" style="margin-bottom: 40px;border: 1px solid #DDDDDD;">
				<tr>
					<th>
						<?php echo ($app["title"]); ?>&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="<?php echo U('Admin/Rbac/addNode',array('pid'=>$app['id'],'level'=>'2'));?>" class="btn btn-xs btn-success">添加控制器</a>
						<a href="<?php echo U('Admin/Rbac/editNode',array('id'=>$app['id']));?>" class="btn btn-xs btn-warning">编辑</a>
						<a href='javascript:if(confirm("确定删除吗？")) location.href="<?php echo U('Rbac/delNode',array('id'=>$app['id']));?>";' class="btn btn-xs btn-danger">删除</a>
					</th>
				</tr>
				<?php if(is_array($app["child"])): foreach($app["child"] as $key=>$action): ?><tr>
						<td class="active">
							<span style="padding-right: 1%;"><?php echo ($action["title"]); ?></span>
							<a href="<?php echo U('Admin/Rbac/addNode',array('pid'=>$action['id'],'level'=>'3'));?>" class="btn btn-xs btn-success">添加方法</a>
							<a href="<?php echo U('Admin/Rbac/editNode',array('id'=>$action['id']));?>" class="btn btn-xs btn-warning">编辑</a>
							<a href='javascript:if(confirm("确定删除吗？")) location.href="<?php echo U('Rbac/delNode',array('id'=>$action['id']));?>";' class="btn btn-xs btn-danger">删除</a>
						</td>
					</tr>
					<tr>
						<td>
							<?php if(is_array($action["child"])): foreach($action["child"] as $key=>$method): ?><span class="" style="display:inline-block; padding:5px 8px;border:1px solid #DDDDDD;margin-right: 20px;margin-bottom: 10px;border-radius: 5px;">
									<span><?php echo ($method["title"]); ?></span>
									<a href="<?php echo U('Admin/Rbac/editNode',array('id'=>$method['id']));?>" class="btn btn-xs btn-warning">编辑</a>
									<a href='javascript:if(confirm("确定删除吗？")) location.href="<?php echo U('Rbac/delNode',array('id'=>$method['id']));?>";' class="btn btn-xs btn-danger">删除</a>
								</span><?php endforeach; endif; ?>
						</td>
					</tr><?php endforeach; endif; ?>
			</table><?php endforeach; endif; ?>

	</body>
</html>