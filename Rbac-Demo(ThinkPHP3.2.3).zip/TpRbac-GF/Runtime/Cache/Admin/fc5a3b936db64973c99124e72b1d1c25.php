<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>角色(分组)列表</title>
		<meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">
	    <!-- Loading Bootstrap -->
	    <link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/vendor/bootstrap.min.css" rel="stylesheet">
	    <!-- Loading Flat UI -->
	    <link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>dist/css/flat-ui.css" rel="stylesheet">
	    <!--<link href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>docs/assets/css/demo.css" rel="stylesheet">-->
	    <link rel="shortcut icon" href="<?php echo (ADMIN_PUBLIC_DIR_FLAT); ?>img/favicon.ico">
	   
	</head>
	<body>
		<div class="alert alert-success" style="text-align: center;">角色(分组)列表</div>
		<table class="table table-hover" style="border: 1px solid #DDDDDD;">
			<tr class="active">
				<th>角色(分组)ID</th>
				<th>角色(分组)名称</th>
				<th>角色(分组)描述</th>
				<th>角色(分组)状态</th>
				<th colspan="2" style="text-align: center;">操作</th>
			</tr>
			<?php if(is_array($roleData)): foreach($roleData as $key=>$vo): ?><tr>
					<td><?php echo ($vo["id"]); ?></td>
					<td><?php echo ($vo["name"]); ?></td>
					<td><?php echo ($vo["remark"]); ?></td>
					<td>
						<?php if($vo["status"] == 1): ?>开启<?php else: ?>关闭<?php endif; ?>
					</td>
					<td style="text-align: center;">
						<a href="<?php echo U('Admin/Rbac/access',array('id'=>$vo['id']));?>" class="btn btn-sm btn-success">分配权限</a>
						<a href="<?php echo U('Admin/Rbac/editRole',array('id'=>$vo['id']));?>" class="btn btn-sm btn-warning">编辑</a>
						<a href='javascript:if(confirm("确定删除吗？")) location.href="<?php echo U('Rbac/delRole',array('id'=>$vo['id']));?>";' class="btn btn-sm btn-danger">删除</a>
					</td>
				</tr><?php endforeach; endif; ?>
		</table>
	</body>
</html>