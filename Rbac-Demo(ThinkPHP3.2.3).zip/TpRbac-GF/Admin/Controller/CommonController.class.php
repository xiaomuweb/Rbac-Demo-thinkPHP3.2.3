<?php
namespace Admin\Controller;
use Think\Controller;
use Org\Util\Rbac;

//公共控制器
class CommonController extends Controller {
    //登录检测
    public function _initialize(){
        if(!isset($_SESSION[C('USER_AUTH_KEY')])){
            //跳转到登录页
            $this->error('您还没有登录哦！',U('Admin/Login/index'),2);
        }
        //不需要验证的控制器和方法
        $notAuth = in_array(MODULE_NAME, explode(',' ,C('NOT_AUTH_MODULE'))) || in_array(ACTION_NAME, explode(',' ,C('NOT_AUTH_MODULE')));
        if(C('USER_AUTH_ON') && !$notAuth){
            import('Org.Util.Rbac');
            //AccessDecision($appName=MODULE_NAME)有应用分组情况必须填上应用名
            Rbac::AccessDecision(MODULE_NAME) || $this->error('您没有权限！');
        }
    }
}