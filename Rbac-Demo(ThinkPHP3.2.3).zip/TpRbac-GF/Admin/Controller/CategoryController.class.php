<?php
namespace Admin\Controller;

//分类控制器
class CategoryController extends CommonController{
    //分类列表
    public function index(){
        $this->display();
    }
    //分类添加
    public function addCategory(){
        $this->display();
    }

}