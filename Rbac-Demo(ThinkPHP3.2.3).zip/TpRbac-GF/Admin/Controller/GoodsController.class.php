<?php
namespace Admin\Controller;

//商品控制器
class GoodsController extends CommonController{
    //商品列表
    public function index(){
        $this->display();
    }
    //商品添加
    public function addGoods(){
        $this->display();
    }

}