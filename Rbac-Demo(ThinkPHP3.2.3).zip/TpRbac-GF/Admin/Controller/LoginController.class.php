<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Verify;
use Org\Util\Rbac;

//登录控制器
class LoginController extends Controller{
    //后台管理员登录页
    public function index(){
        if(IS_POST) {
            //一、判断验证码是否正确
            $verify = new Verify();
            if($verify->check(I('post.code'))) {
                //二、用户民与密码验证
                //(1)验证用户名
                $userData = D('user');
                $user = $userData->checkLogin(I('post.name'), I('post.password'));
                if($user) {
                    //session持久化用户信息(id/name)
                    session(C('USER_AUTH_KEY'), $user['id']);
                    session('username',$user['name']);

                    //判断是否是超级管理员
                    if($user['name'] == C('RBAC_SUPERADMIN')){
                        session(C('ADMIN_AUTH_KEY'),true);
                    }
                    //引入RBAC类
                    import('Org.Util.Rbac');
                    //读取用户权限
                    Rbac::saveAccessList();

                    $this->redirect('Index/index', '', 1, '正在登陆...');
                } else {
                    $this->error('用户名或密码错误');
                }
            } else {
                $this->error('验证码错误',U('index'),1);
            }
        }
        $this-> display();
    }

    //安全退出
    public function out(){
        //session_unset();
        //session_destroy();
        session(null);
        $this->success('已安全退出',U('index'),1);
    }

    //验证码
    public function verifyShow(){
        //验证码设置
        $config = array(
            'useImgBg' => false,            // 使用背景图片
            'fontSize' => 16,              // 验证码字体大小(px)
            'useCurve' => true,            // 是否画混淆曲线
            'useNoise' => false,           // 是否添加杂点
            'imageH'   => 45,              // 验证码图片高度
            'imageW'   => 110,             // 验证码图片宽度
            'length'   => 4,               // 验证码位数
            'fontttf'  => '',              // 验证码字体，不设置随机获取
            'bg'       => array(243, 251, 254),  // 背景颜色
            'reset'    => true,           // 验证成功后是否重置
        );
        $verify = new Verify($config);
        //验证码输出
        $verify->entry();
    }

}