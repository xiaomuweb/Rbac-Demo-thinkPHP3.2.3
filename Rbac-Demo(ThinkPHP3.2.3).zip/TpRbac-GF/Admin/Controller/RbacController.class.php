<?php
/**
 * Rbac权限管理控制器
 * access表需添加一个pid字段，其值就是相应节点的pid值
 */
namespace Admin\Controller;

class RbacController extends CommonController{
    /**
     * 检测是否含有中文
     */
    public function test_zw($var){
        if(preg_match('/[\x{4e00}-\x{9fa5}]/u', $var)>0) {
            return true; //含有中文
        } else {
            return false; //没有中文
        }
    }
    /**
     * 角色管理
     * -- --------------------------------------------------------
     */
    //角色列表
    public function role(){
        $roleData = M('role')->select();
        $this->assign('roleData',$roleData);
        $this->display();
    }
    //添加角色
    public function addRole(){
        if(IS_POST){
            if(!empty(I('post.name')) && !empty(I('post.remark'))){
                //角色名不能重复
                $roleName = M('role')->getField('name',true);
                if(in_array(strtolower(I('post.name')) ,$roleName)){
                    $this->error('角色名已存在，请换成其它名称！');
                    return;
                }else{
                    $data = I('post.');
                    $id = M('role')->add($data);
                    if($id){
                        //更新角色pid
                        $res = M('role')->where(array('id'=>$id))->setField('pid',$id);
                        if($res){
                            $this->success('角色添加成功',U('role'),1);
                        }else{
                            $this->error('角色pid更新失败，请手动更改为pid为当前id值');
                        }
                    }else{
                        $this->error('角色添加失败，请重试');
                    }
                }
            }else{
                $this->error('角色名称和描述不能为空,请重新添加');
            }
        }else{
            $this->display();
        }
    }
    //编辑修改角色
    public function editRole($id){
        //获取旧数据
        $oldRolData = M('role')->find($id);
        $this->assign('oldRolData',$oldRolData);
        if(IS_POST){
            if(!empty(I('post.name')) && !empty(I('post.remark'))){
                //角色名不能重复
                $map['id'] = array('neq',$id);
                $roleName = M('role')->where($map)->getField('name',true);
                if(in_array(strtolower(I('post.name')) ,$roleName)){
                    $this->error('角色名与其它角色冲突，请更换名称！');
                    return;
                }
                $res = M('role')->save(I('post.'));
                if($res === false){
                    $this->error('角色编辑失败，请重试！');
                }else{
                    $this->success('角色编辑成功',U('role'),1);
                }
            }else{
                $this->error('角色名称和描述不能为空,请重新编辑');
            }
        }else{
            $this->display();
        }
    }
    //删除角色
    public function delRole($id){
        //删除角色
        $res = M('role')->delete($id);
        if($res){
            $this->success('角色删除成功',U('role'));
        }else{
            $this->error('角色删除失败');
        }
    }
    /**
     * 节点管理
     * -- --------------------------------------------------------
     */
    //节点列表
    public function node(){
        $field = array('id','name','title','pid','status');
        $nodeData = M('node')->field($field)->order('sort')->select();
        $this->nodeData = node_merage($nodeData); //递归重组节点信息为多维数组(Admin/Common/function.php)
        $this->display();
    }
    //添加节点
    public function addNode(){
        $this->pid = I('pid',0,'intval');
        $this->level = I('level',1,'intval');
        //根据level的值判断当前节点类型
        switch($this->level){
            case 1:
                $this->type = '应用';
                break;
            case 2:
                $this->type = '控制器';
                break;
            case 3:
                $this->type = '操作方法';
                break;
        }
        $this->display();
    }
    //编辑、添加节点表单处理
    public function nodeHandel(){
        if(IS_POST){
            if(!empty(I('post.name')) && !empty(I('post.title'))){
                //是否为英文
                if($this->test_zw(I('post.name'))){
                    $this->error('名称必须为全英文，不能含有中文！');
                    return;
                }
                //有传递过来id值就是修改，否则就是添加
                $nodeData = M('node');
                $id = I('post.id');
                $level = I('post.level');
                //应用和控制器首字母大写
                $data = I('post.');
                if($level == 1 || $level == 2){
                    $data['name'] = I('post.name','','ucfirst');
                }
                //修改节点
                if(!empty($id)){
                    //同一级别、父节点下的子节点不能重名（不包含当前修改的名称）
                    $map1['name'] = array('neq',$data['name']);
                    $map1['pid'] = array('eq',$data['pid']);
                    $map1['level'] = array('eq',$level);
                    $checkName1 = M('node')->where($map1)->getField('name',true);
                    $res1 = in_array(strtolower($data['name']) ,array_map('strtolower', $checkName1));
                    if($res1){
                        $this->error('该级别节点下已存在'.$data['name'].'节点，请换一个名称！');
                        return;
                    }
                    if($nodeData->save($data)){
                        $this->success('编辑成功',U('node'),1);
                    }else{
                        $this->error('未做任何修改');
                    }
                }else{//添加节点
                    ////同一级别、父节点下的子节点不能重名
                    $map2['level'] = array('eq',$level);
                    $map2['pid'] = array('eq',$data['pid']);
                    $checkName2 = M('node')->where($map2)->getField('name',true);
                    $res2 = in_array(strtolower($data['name']) ,array_map('strtolower', $checkName2));
                    if($res2){
                        $this->error('该级别节点下已存在'.$data['name'].'节点，请换一个名称！');
                        return;
                    }
                    if($nodeData->add($data)){
                        $this->success('添加成功',U('node'),1);
                    }else{
                        $this->error('添加失败');
                    }
                }

            }else{
                $this->error('名称和描述不能为空,请重新添加');
            }
        }else{
            $this->display();
        }
    }
    //编辑修改节点
    public function editNode($id){
        $this->nodeData = M('node')->find($id);
        //根据level的值判断当前节点类型
        switch($this->nodeData['level']){
            case 1:
                $this->type = '应用';
                break;
            case 2:
                $this->type = '控制器';
                break;
            case 3:
                $this->type = '操作方法';
                break;
        }
        $this->display();
    }
    //删除节点
    public function delNode(){
        $nodeData = M('node');
        $id = I('get.id');
        //如果有pid=$id说明就有子节点，要删除下面所有子节点才能删除该节点
        $res = $nodeData->where(array('pid'=>$id))->select();
        if($res){
            $this->error('请先删除该节点下的全部子节点！');
        }else{
            if($nodeData->delete($id)){
                //删除access表
                if(M('access')->where(array('node_id'=>$id))->find()){
                    if(M('access')->where(array('node_id'=>$id))->delete()){
                        $this->success('删除节点成功',U('node'),1);
                    }else{
                        $this->error('access表相关数据未能删除!');
                    }
                }
                $this->success('删除节点成功',U('node'),1);
            }else{
                $this->error('删除节点失败，请重试！');
            }
        }
    }
    /**
     * 节点（就是应用，控制器，操作方法）管理
     * -- --------------------------------------------------------
     */
    //分配权限列表
    public function access(){
        //角色信息(id,名字)
        $rid = I('id',0, 'intval');
        $this->rid = $rid;
        $this->name = M('role')->where(array('id'=>$rid))->getField('name');
        //节点信息
        $node = M('node')->order('sort')->select();
        $this->node = node_merage($node);
        //编辑修改已分配过的权限，选中原来已经有的权限
        $accessData = M('access');
        //原有权限的ID
        $nids = $accessData->where(array('role_id'=>$rid))->getField('node_id',true);
        $this->nids = $nids;
        $this->display();
    }
    //添加、修改权限
    public function editAccess(){
        $rid = I('get.rid');
        if(IS_POST && !empty(I('post.'))){
            $data  = I('post.');  //数组access为权限信息：'节点id-level等级'数组形式
            //拆分出access中的节点和level,组合新权限
            $arr = array();
            foreach($data['access'] as $v){
                $tmp = explode('-',$v);
                $arr[] = array(
                    'role_id' => $rid, //角色标识
                    'node_id' => $tmp[0], //权限标识
                    'level'   => $tmp[1] //level等级);
                );
            }
            $accessData = M('access');
            //修改权限时先删除原来的权限
            $accessData->where(array('role_id'=>$rid))->delete();
            if($accessData->addAll($arr)){
                $this->redirect('role','',1,'权限分配成功');
            }else{
                $this->error('权限分配失败');
            }
        }else{
           $this->error('权限分配失败，请至少选择一个权限！');
        }
    }
    /**
     * 用户管理
     * -- --------------------------------------------------------
     */
    //用户列表
    public function user(){
        $this->userData = D('UserRelation')->relation(true)->select();
        $this->display();
    }
    //添加用户
    public function addUser(){
        //角色数据
        $this->roleData = M('role')->field('id,name')->select();
        $this->display();
    }
    //添加、修改用户表单处理
    public function userHandel(){
        //数据接收
        if(IS_POST && !empty(I('post.name')) &&!empty(I('post.password'))){
            //如果提交过来的数据有id,就是编辑修改，否则就是添加
            $id = I('post.id');
            $userData = M('user');
            $ruData = M('role_user');
            $arr = array(
                'name' => I('post.name'),
                'password' => md5(I('post.password'))
            );
            if(!empty($id)){
                //编辑修改用户
                //除了本身用户名外不能与其它用户名重复
                $map['id'] = array('neq',$id);
                $userNames1 = $userData->where($map)->getField('name',true);
                if(in_array(strtolower(I('post.name')),$userNames1)){
                    $this->error('与其它用户名冲突，请更换名称！');
                    return;
                }
                //用户-角色中间表
                if($userData->where(array('id'=>$id))->save($arr) === false){
                    $this->error('用户修改失败,请重试！');
                }else{
                    $arr1 = array();
                    foreach(I('post.role_id') as $v){
                        $arr1[] = array(
                            'user_id' => $id,
                            'role_id' => $v
                        );
                    }
                    //修改用户-角色中间表时先删除原来的
                    $ruData->where(array('user_id'=>$id))->delete();
                    if($ruData->addAll($arr1)){
                        $this->success('用户修改成功','user',1);
                    }else{
                        $this->success('用户修改成功，但该用户未选择角色！','user',1);
                    }
                }

            }else{
                //添加用户
                //用户名不能重复
                $userNames2 = $userData->getField('name',true);
                if(in_array(strtolower(I('post.name')),$userNames2)){
                    $this->error('用户名已存在，请换成其它名称！');
                    return;
                }
                if($uid = $userData->add($arr)){
                    //用户-角色中间表
                    $arr2 = array();
                    foreach(I('post.role_id') as $v){
                        $arr2[] = array(
                            'user_id' => $uid,
                            'role_id' => $v
                        );
                    }
                    if(M('role_user')->addAll($arr2)){
                        $this->success('用户添加成功','user',1);
                    }else{
                        $this->success('用户添加成功，但该用户未选择角色！','user',1);
                    }
                }else{
                    $this->error('用户添加失败，请重试！');
                }
            }
        }else{
           $this->error('用户名和密码不能为空！');
        }
    }
    //编辑修改用户
    public function editUser($id){
        $this->roleData = M('role')->field('id,name')->select();
        $this->userData = D('UserRelation')->relation(true)->field('id,name')->find($id);
        $role_ids = array(); //获取原来所属角色的id
        foreach($this->userData['role'] as $v){
            $role_ids[] = $v['id'];
        }
        $this->assign('role_ids',$role_ids);
        $this->display();
    }
    //删除用户
    public function delUser($id){
        //删除用户表
        if(M('user')->delete($id)){
            if(M('role_user')->where(array('user_id'=>$id))->delete()){
                //删除用户-角色关联表
                $this->success('删除用户成功',U('user'),1);
            }else{
                $this->error("用户-角色关联表删除失败，请手动删除think_role_user表中user_id等于{$id}的数据！",U('user'),10);
            }
        }else{
            $this->error('删除用户失败，请重试！');
        }
    }

}