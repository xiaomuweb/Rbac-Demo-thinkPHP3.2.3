<?php
namespace Admin\Controller;

//首页控制器
class IndexController extends CommonController{
    //首页
    public function index(){
        //获取当前账号所属角色
        $id = $_SESSION[C('USER_AUTH_KEY')];
        $data= D('UserRelation')->relation(true)->where(array('id'=>$id))->find();
        $this->role = $data['role'][0]['name'];
        $this->display();
    }
    //欢迎界面
    public function welcome(){
        $this->display();
    }
    //密码修改
    public function changePwd(){
        $user = D('user');
        //获取当前管理员数据表信息
        $id = $_SESSION[C('USER_AUTH_KEY')]; // 当前管理员Id
        $userData = $user->find($id);
        if(IS_POST) {
            //1.验证原密码是否正确
            $oldPassword = md5(I('post.oldPassword'));
            if($oldPassword === $userData['password']) {
                //原密码是否正确
                //验证新密码：
                //1.密码不能少于六位
                $newPassword = I('post.newPassword');
                $confPassword = I('post.confirmPassword');
                if(strlen($newPassword) >= 6) {
                    //2.新密码不能与原密码一样
                    if(md5($newPassword) !== $userData['password']){
                        //3.两次密码输入要一致
                        if($newPassword === $confPassword) {
                            //新密码修改成功，跳转到首页
                            $user->password = md5($newPassword);
                            if($user->where(array('id'=>$id))->save()){
                                session(null);
                                echo "<script> alert('密码修改成功，请重新登录!');parent.location.href='".U('Login/index')."'</script>";
                            }

                        } else {
                            $this->error('两次密码不一致，请重新输入!');
                        }
                    }else{
                        $this->error('新密码不能与原密码一样');
                    }
                } else {
                    $this->error('密码少于六位，请重新输入');
                }
            } else { //原密码有误
                $this->error('原密码不正确，请重新输入');
            }
        }
        $this->display();
    }
}