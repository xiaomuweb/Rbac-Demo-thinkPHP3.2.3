<?php
/**
 * 递归重组节点信息为多维数组
 * @param array $node  要处理的节点数组
 * @param int $pid     父级id
 */
function node_merage($node, $pid = 0){
    $arr = array();
    foreach($node as $v){
        if($v['pid'] == $pid){
            $v['child'] = node_merage($node, $v['id']);
            $arr[] = $v;
        }
    }
    return $arr;
}