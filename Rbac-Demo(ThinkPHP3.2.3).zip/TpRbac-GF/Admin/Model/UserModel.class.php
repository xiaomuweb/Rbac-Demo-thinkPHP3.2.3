<?php
/**
 * 登录模型
 * Date: 2017/3/27
 * Time: 23:31
 */

namespace Admin\Model;
use Think\Model;

class UserModel extends Model{
    //指定表名
    protected $tableName = 'user';

    //登录时用户名与密码验证
    public function checkLogin($name, $pwd){
        //1.根据$name判断用户名是否存在
        $user = $this->where("name='$name'")->find();
        //2.如果用户名存在，则根据用户名信息和$pwd作对比，判断密码是否正确
        if($user){
            if($user['password'] === md5($pwd)){
                return $user;
            }
        }
        return null;
    }
}