<?php
/**
 * 用户表与角色表关联模型
 */

namespace Admin\Model;
use Think\Model\RelationModel;

class UserRelationModel extends RelationModel{
    protected $tableName = 'user'; //定义主表名称
    //定义关联关系
    protected $_link = array(
        'role' => array( //要关联的表
            'mapping_type' => self::MANY_TO_MANY,
            'foreign_key'  => 'user_id',   //foreign_key 主表关联的外键名称 外键的默认规则是当前数据对象名称_id
            'relation_foreign_key' => 'role_id',   //relation_foreign_key 副表关联表的外键名称 默认的关联表的外键名称是表名_id
            'relation_table' => 'think_role_user',   //relation_table	多对多的中间关联表名称
            'mapping_fields' => 'id,name,remark'    //查询个别字段
        )
    );
}