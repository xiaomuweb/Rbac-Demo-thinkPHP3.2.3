/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50637
Source Host           : localhost:3306
Source Database       : tprbac-gf

Target Server Type    : MYSQL
Target Server Version : 50637
File Encoding         : 65001

Date: 2017-12-26 21:37:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `think_access`
-- ----------------------------
DROP TABLE IF EXISTS `think_access`;
CREATE TABLE `think_access` (
  `role_id` smallint(6) unsigned NOT NULL COMMENT '角色标识',
  `node_id` smallint(6) unsigned NOT NULL COMMENT '权限标识',
  `level` tinyint(1) NOT NULL COMMENT '层次等级',
  `module` varchar(50) DEFAULT NULL COMMENT '模块（控制器）',
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='权限表';

-- ----------------------------
-- Records of think_access
-- ----------------------------
INSERT INTO `think_access` VALUES ('1', '35', '3', null);
INSERT INTO `think_access` VALUES ('1', '34', '3', null);
INSERT INTO `think_access` VALUES ('1', '33', '3', null);
INSERT INTO `think_access` VALUES ('1', '32', '3', null);
INSERT INTO `think_access` VALUES ('2', '14', '3', null);
INSERT INTO `think_access` VALUES ('2', '13', '3', null);
INSERT INTO `think_access` VALUES ('2', '12', '2', null);
INSERT INTO `think_access` VALUES ('2', '1', '1', null);
INSERT INTO `think_access` VALUES ('1', '5', '3', null);
INSERT INTO `think_access` VALUES ('1', '4', '3', null);
INSERT INTO `think_access` VALUES ('1', '6', '3', null);
INSERT INTO `think_access` VALUES ('1', '3', '2', null);
INSERT INTO `think_access` VALUES ('1', '31', '3', null);
INSERT INTO `think_access` VALUES ('1', '30', '3', null);
INSERT INTO `think_access` VALUES ('1', '29', '3', null);
INSERT INTO `think_access` VALUES ('1', '28', '3', null);
INSERT INTO `think_access` VALUES ('1', '27', '3', null);
INSERT INTO `think_access` VALUES ('1', '26', '3', null);
INSERT INTO `think_access` VALUES ('1', '25', '3', null);
INSERT INTO `think_access` VALUES ('1', '24', '3', null);
INSERT INTO `think_access` VALUES ('1', '23', '3', null);
INSERT INTO `think_access` VALUES ('1', '22', '3', null);
INSERT INTO `think_access` VALUES ('1', '21', '3', null);
INSERT INTO `think_access` VALUES ('1', '20', '3', null);
INSERT INTO `think_access` VALUES ('1', '19', '2', null);
INSERT INTO `think_access` VALUES ('1', '1', '1', null);
INSERT INTO `think_access` VALUES ('3', '9', '3', null);
INSERT INTO `think_access` VALUES ('3', '8', '3', null);
INSERT INTO `think_access` VALUES ('3', '7', '2', null);
INSERT INTO `think_access` VALUES ('3', '1', '1', null);

-- ----------------------------
-- Table structure for `think_node`
-- ----------------------------
DROP TABLE IF EXISTS `think_node`;
CREATE TABLE `think_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '节点标识',
  `name` varchar(20) NOT NULL COMMENT '节点英文名',
  `title` varchar(50) DEFAULT NULL COMMENT '节点中文名',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态（为1时该权限才能生效）',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `sort` smallint(6) unsigned DEFAULT '1' COMMENT '排序',
  `pid` smallint(6) unsigned NOT NULL COMMENT '父标识（0为顶级，依次推）',
  `level` tinyint(1) unsigned NOT NULL COMMENT '等级（1为应用（后台，前台），2为模块（控制器），3为方法）',
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COMMENT='节点表';

-- ----------------------------
-- Records of think_node
-- ----------------------------
INSERT INTO `think_node` VALUES ('1', 'Admin', '后台应用', '1', null, '1', '0', '1');
INSERT INTO `think_node` VALUES ('2', 'Home', '前台应用', '1', null, '2', '0', '1');
INSERT INTO `think_node` VALUES ('3', 'Index', '后台首页控制器', '1', null, '1', '1', '2');
INSERT INTO `think_node` VALUES ('4', 'index', '首页列表', '1', null, '1', '3', '3');
INSERT INTO `think_node` VALUES ('5', 'welcome', '欢迎界面', '1', null, '2', '3', '3');
INSERT INTO `think_node` VALUES ('6', 'changePwd', '密码修改', '1', null, '1', '3', '3');
INSERT INTO `think_node` VALUES ('7', 'Category', '分类控制器', '1', null, '2', '1', '2');
INSERT INTO `think_node` VALUES ('8', 'index', '分类列表', '1', null, '1', '7', '3');
INSERT INTO `think_node` VALUES ('9', 'addCategory', '添加分类', '1', null, '2', '7', '3');
INSERT INTO `think_node` VALUES ('57', 'Index', '测试节点首页', '1', null, '1', '56', '2');
INSERT INTO `think_node` VALUES ('56', 'Test', '测试节点', '1', null, '1', '0', '1');
INSERT INTO `think_node` VALUES ('12', 'Goods', '商品控制器', '1', null, '3', '1', '2');
INSERT INTO `think_node` VALUES ('13', 'index', '商品列表', '1', null, '1', '12', '3');
INSERT INTO `think_node` VALUES ('14', 'addGoods', '商品添加', '1', null, '2', '12', '3');
INSERT INTO `think_node` VALUES ('15', 'Login', '登录控制器', '1', null, '4', '1', '2');
INSERT INTO `think_node` VALUES ('16', 'index', '登录页', '1', null, '1', '15', '3');
INSERT INTO `think_node` VALUES ('17', 'out', '安全退出', '1', null, '2', '15', '3');
INSERT INTO `think_node` VALUES ('18', 'verifyShow', '验证码', '1', null, '3', '15', '3');
INSERT INTO `think_node` VALUES ('19', 'Rbac', 'Rbac权限管理控制器', '1', null, '0', '1', '2');
INSERT INTO `think_node` VALUES ('20', 'role', '角色列表', '1', null, '1', '19', '3');
INSERT INTO `think_node` VALUES ('21', 'addRole', '添加角色', '1', null, '2', '19', '3');
INSERT INTO `think_node` VALUES ('22', 'editRole', '修改角色', '1', null, '3', '19', '3');
INSERT INTO `think_node` VALUES ('23', 'delRole', '删除角色', '1', null, '4', '19', '3');
INSERT INTO `think_node` VALUES ('24', 'node', '节点列表', '1', null, '5', '19', '3');
INSERT INTO `think_node` VALUES ('25', 'addNode', '添加节点', '1', null, '6', '19', '3');
INSERT INTO `think_node` VALUES ('26', 'editNode', '修改节点', '1', null, '7', '19', '3');
INSERT INTO `think_node` VALUES ('27', 'delNode', '删除节点', '1', null, '8', '19', '3');
INSERT INTO `think_node` VALUES ('28', 'nodeHandel', '编辑、添加节点表单处理', '1', null, '9', '19', '3');
INSERT INTO `think_node` VALUES ('29', 'access', '分配权限列表', '1', null, '10', '19', '3');
INSERT INTO `think_node` VALUES ('30', 'editAccess', '添加、修改权限', '1', null, '11', '19', '3');
INSERT INTO `think_node` VALUES ('31', 'user', '用户列表', '1', null, '13', '19', '3');
INSERT INTO `think_node` VALUES ('32', 'addUser', '添加用户', '1', null, '14', '19', '3');
INSERT INTO `think_node` VALUES ('33', 'editUser', '修改用户', '1', null, '15', '19', '3');
INSERT INTO `think_node` VALUES ('34', 'delUser', '删除用户', '1', null, '16', '19', '3');
INSERT INTO `think_node` VALUES ('35', 'userHandel', '添加、修改用户表单处理', '1', null, '17', '19', '3');
INSERT INTO `think_node` VALUES ('36', 'Index', '前台首页控制器', '1', null, '1', '2', '2');
INSERT INTO `think_node` VALUES ('37', 'index', '前台首页', '1', null, '1', '36', '3');

-- ----------------------------
-- Table structure for `think_role`
-- ----------------------------
DROP TABLE IF EXISTS `think_role`;
CREATE TABLE `think_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色标识',
  `name` varchar(20) NOT NULL COMMENT '角色名称',
  `pid` smallint(6) DEFAULT '1' COMMENT '父ID(0为超级管理员，1为其他)',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '状态（1为开启，0未开启，只有开启该角色的权限才能生效）',
  `remark` varchar(255) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='角色（分组）表';

-- ----------------------------
-- Records of think_role
-- ----------------------------
INSERT INTO `think_role` VALUES ('1', '网站管理员', '1', '1', '网站管理');
INSERT INTO `think_role` VALUES ('2', '商品管理员', '2', '1', '商品管理');
INSERT INTO `think_role` VALUES ('3', '分类管理员', '3', '1', '分类管理');

-- ----------------------------
-- Table structure for `think_role_user`
-- ----------------------------
DROP TABLE IF EXISTS `think_role_user`;
CREATE TABLE `think_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL COMMENT '角色标识',
  `user_id` char(32) DEFAULT NULL COMMENT '用户标识',
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色（分组）-用户中间表';

-- ----------------------------
-- Records of think_role_user
-- ----------------------------
INSERT INTO `think_role_user` VALUES ('1', '2');
INSERT INTO `think_role_user` VALUES ('2', '3');
INSERT INTO `think_role_user` VALUES ('3', '4');
INSERT INTO `think_role_user` VALUES ('2', '4');

-- ----------------------------
-- Table structure for `think_user`
-- ----------------------------
DROP TABLE IF EXISTS `think_user`;
CREATE TABLE `think_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户标识',
  `name` varchar(60) NOT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `status` varchar(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of think_user
-- ----------------------------
INSERT INTO `think_user` VALUES ('1', 'admin', '7fef6171469e80d32c0559f88b377245', '0');
INSERT INTO `think_user` VALUES ('2', 'lisi', '7fef6171469e80d32c0559f88b377245', '1');
INSERT INTO `think_user` VALUES ('3', 'wang', '7fef6171469e80d32c0559f88b377245', '1');
INSERT INTO `think_user` VALUES ('4', 'liu', '7fef6171469e80d32c0559f88b377245', '1');
